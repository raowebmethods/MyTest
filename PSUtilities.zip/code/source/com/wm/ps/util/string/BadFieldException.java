package com.wm.ps.util.string;

public class BadFieldException extends Exception
{
  public BadFieldException(String message)
  {
    super(message);
  }
}